package rest3.rest3question;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Rest3questionApplication {

	public static void main(String[] args) {
		SpringApplication.run(Rest3questionApplication.class, args);
	}

}
