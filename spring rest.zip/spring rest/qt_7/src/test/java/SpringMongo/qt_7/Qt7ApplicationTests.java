package SpringMongo.qt_7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Qt7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
