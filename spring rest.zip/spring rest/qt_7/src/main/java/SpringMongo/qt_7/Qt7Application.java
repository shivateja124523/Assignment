package SpringMongo.qt_7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Qt7Application {

	public static void main(String[] args) {
		SpringApplication.run(Qt7Application.class, args);
	}

}
