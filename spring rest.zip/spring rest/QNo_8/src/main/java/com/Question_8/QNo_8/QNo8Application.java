package com.Question_8.QNo_8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QNo8Application {

	public static void main(String[] args) {
		SpringApplication.run(QNo8Application.class, args);
	}

}
