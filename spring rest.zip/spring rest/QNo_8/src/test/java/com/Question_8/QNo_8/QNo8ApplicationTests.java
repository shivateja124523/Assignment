package com.Question_8.QNo_8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QNo8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
