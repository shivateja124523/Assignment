const json = '{"firstName":"Mohammed", "lastName":"Shuaib"}';
const obj = JSON.parse(json);

console.log(obj.firstName);
console.log(obj.lastName);
